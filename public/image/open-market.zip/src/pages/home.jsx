import { Main } from "../components/main/main";

const Home = () => {
  return <Main />;
};

export default Home;
