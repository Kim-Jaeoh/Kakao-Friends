import { Detail } from "../components/product_detail/detail";

const Product = () => {
  return <Detail />;
};

export default Product;
