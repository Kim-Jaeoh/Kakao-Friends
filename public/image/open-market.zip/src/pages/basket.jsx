import { Cart } from "../components/cart/cart";

const Basket = () => {
  return <Cart />;
};

export default Basket;
